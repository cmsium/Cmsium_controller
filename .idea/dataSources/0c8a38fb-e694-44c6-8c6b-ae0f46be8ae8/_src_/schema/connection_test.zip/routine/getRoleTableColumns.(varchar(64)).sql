CREATE PROCEDURE getRoleTableColumns(IN tableName VARCHAR(64))
  BEGIN
    SELECT column_name, column_type, is_nullable
    FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = CONCAT(tableName,'_properties');
END;
