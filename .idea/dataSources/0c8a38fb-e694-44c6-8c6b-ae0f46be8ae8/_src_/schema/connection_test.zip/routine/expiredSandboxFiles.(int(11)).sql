CREATE PROCEDURE expiredSandboxFiles(IN expiredMinutes INT)
  BEGIN
    SELECT file_id FROM sandbox_files WHERE TIMESTAMPDIFF(MINUTE,created_at,NOW()) > expiredMinutes;
  END;
