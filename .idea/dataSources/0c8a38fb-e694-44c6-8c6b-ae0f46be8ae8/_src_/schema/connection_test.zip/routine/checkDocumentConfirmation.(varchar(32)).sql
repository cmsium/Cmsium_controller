CREATE PROCEDURE checkDocumentConfirmation(IN idDocument VARCHAR(32))
  BEGIN
    SELECT document_id FROM document_destroy_confirmation WHERE document_id = idDocument;
  END;
