CREATE PROCEDURE readDocument(IN tableName VARCHAR(64), IN idDocument VARCHAR(32))
  BEGIN
    SET @sql = CONCAT('SELECT * FROM ',
                      tableName,
                      ' WHERE document_id="',
                      idDocument,
                      '";');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END;
