CREATE PROCEDURE getTableSchema(IN tableName VARCHAR(64))
  BEGIN
    SELECT column_name, column_type, column_key
    FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name =  tableName;
  END;
