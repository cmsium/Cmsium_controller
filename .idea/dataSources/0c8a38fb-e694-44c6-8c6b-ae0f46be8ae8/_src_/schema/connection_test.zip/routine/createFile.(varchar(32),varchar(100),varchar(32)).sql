CREATE PROCEDURE createFile(IN idFile VARCHAR(32), IN fileName VARCHAR(100), IN idOwner VARCHAR(32))
  BEGIN
    INSERT INTO files (file_id, path, created_at, name, owner_id) VALUES (idFile,'future',NOW(),fileName,idOwner);
  END;
