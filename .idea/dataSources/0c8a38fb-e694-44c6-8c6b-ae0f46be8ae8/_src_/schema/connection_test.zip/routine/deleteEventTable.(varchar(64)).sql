CREATE PROCEDURE deleteEventTable(IN typeName VARCHAR(64))
  BEGIN
    START TRANSACTION;
    SET @sql = CONCAT ('DROP TABLE IF EXISTS ',CONCAT('event_',typeName));
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    DELETE FROM event_types WHERE name = typeName;
    COMMIT;
  END;
