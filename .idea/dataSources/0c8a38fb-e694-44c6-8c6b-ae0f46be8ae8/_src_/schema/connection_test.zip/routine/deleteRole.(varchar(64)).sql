CREATE PROCEDURE deleteRole(IN idRole VARCHAR(64))
  BEGIN
    START TRANSACTION;
    DELETE FROM roles_in_actions WHERE id_role = idRole;
    DELETE FROM roles_in_files WHERE role_id = idRole;
    DELETE FROM roles_in_users WHERE role_id = idRole;
    DELETE FROM roles WHERE id = idRole;
    COMMIT;
  END;
