CREATE PROCEDURE generateFileLink(IN idFile VARCHAR(32))
  BEGIN
     INSERT INTO file_links (file_id, link) VALUES (idFile,md5(concat(file_id,NOW())));
     call checkFileLink(idFile);
END;
