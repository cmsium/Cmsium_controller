CREATE PROCEDURE deleteProps(IN tableName VARCHAR(64), IN idUser VARCHAR(32))
  BEGIN
    SET @sql = CONCAT('DELETE FROM ',
                      tableName,
                      ' WHERE user_id="',
                      idUser,
                      '";');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END;
