CREATE PROCEDURE writeAddressObject(IN tableName VARCHAR(255), IN addressName VARCHAR(45), IN idParent INT,
                                    IN idType    INT)
  BEGIN
    SET @sql = CONCAT('INSERT INTO ',
                      tableName,
                      '(name, parent_id, type_id) VALUES ("',
                      addressName,
                      '",',
                      idParent,
                      ',',
                      idType,
                      ');');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    SELECT last_insert_id() as id;
  END;
