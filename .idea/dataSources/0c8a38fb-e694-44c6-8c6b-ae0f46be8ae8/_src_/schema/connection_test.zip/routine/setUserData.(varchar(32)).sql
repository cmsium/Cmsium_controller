CREATE PROCEDURE setUserData(IN idUser VARCHAR(32))
  BEGIN
    SELECT *,GROUP_CONCAT(DISTINCT roles.id SEPARATOR ', ') AS roles_id, GROUP_CONCAT(DISTINCT roles.name SEPARATOR ', ') AS roles,GROUP_CONCAT(DISTINCT roles.t_name SEPARATOR ', ') AS t_roles
    FROM  user_properties as props
      INNER JOIN phones ON  props.user_id = phones.user_id
      INNER JOIN emails ON props.user_id = emails.user_id
      JOIN roles_in_users AS riu ON props.user_id = riu.user_id
      JOIN roles  ON riu.role_id = roles.id
    WHERE props.user_id = idUser;
  END;
