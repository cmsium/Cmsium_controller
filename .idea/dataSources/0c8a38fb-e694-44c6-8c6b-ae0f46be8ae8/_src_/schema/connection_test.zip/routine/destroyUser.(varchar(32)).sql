CREATE PROCEDURE destroyUser(IN idUser VARCHAR(32))
  BEGIN
    DELETE FROM phones WHERE user_id = idUser;
    DELETE FROM emails WHERE user_id = idUser;
    DELETE FROM user_properties WHERE user_id = idUser;
    DELETE FROM confirmation WHERE user_id = idUser;
    DELETE FROM roles_in_users WHERE user_id = idUser;
    DELETE FROM bus_tickets WHERE id_user = idUser;
  END;
