CREATE PROCEDURE createTempTableStreetsKLADR()
  BEGIN
    DROP TEMPORARY TABLE IF EXISTS kladr_street_temp;
    CREATE TEMPORARY TABLE kladr_street_temp(
      id int(11) NOT NULL AUTO_INCREMENT,
      name varchar(255) NOT NULL,
      code varchar(255) NOT NULL,
      full_code varchar(255) NOT NULL,
      type_id int(11) NOT NULL, PRIMARY KEY (id)
    ) ENGINE=InnoDB;
  END;
