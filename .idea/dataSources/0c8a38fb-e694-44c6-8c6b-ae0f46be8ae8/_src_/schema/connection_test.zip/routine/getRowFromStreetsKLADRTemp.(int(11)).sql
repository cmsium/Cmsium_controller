CREATE PROCEDURE getRowFromStreetsKLADRTemp(IN idRow INT)
  BEGIN
    SELECT * FROM kladr_street_temp WHERE id = idRow;
  END;
