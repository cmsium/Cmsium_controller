CREATE PROCEDURE deleteAllActions()
  BEGIN
    DELETE FROM system_actions;
END;
