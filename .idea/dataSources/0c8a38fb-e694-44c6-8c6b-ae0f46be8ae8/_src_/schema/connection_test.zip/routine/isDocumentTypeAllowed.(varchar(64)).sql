CREATE PROCEDURE isDocumentTypeAllowed(IN typeName VARCHAR(64))
  BEGIN
    SELECT name FROM document_types WHERE name=typeName;
  END;
