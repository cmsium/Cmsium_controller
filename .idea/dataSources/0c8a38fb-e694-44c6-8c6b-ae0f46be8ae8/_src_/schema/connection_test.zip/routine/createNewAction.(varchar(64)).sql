CREATE PROCEDURE createNewAction(IN actionName VARCHAR(64))
  BEGIN
    INSERT INTO system_actions (action_id,name) VALUE (MD5(actionName),actionName);
END;
