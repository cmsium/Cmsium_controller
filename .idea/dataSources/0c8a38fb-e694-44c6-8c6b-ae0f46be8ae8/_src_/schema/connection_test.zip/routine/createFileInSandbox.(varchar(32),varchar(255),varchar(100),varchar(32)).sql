CREATE PROCEDURE createFileInSandbox(IN idFile  VARCHAR(32), IN fileType VARCHAR(255), IN fileName VARCHAR(100),
                                     IN idOwner VARCHAR(32))
  BEGIN
    INSERT INTO sandbox_files (file_id,type, created_at, name, owner_id) VALUES (idFile,fileType,NOW(),fileName,idOwner);
  END;
