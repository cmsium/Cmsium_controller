CREATE PROCEDURE checkEventConfirmation(IN idEvent VARCHAR(32))
  BEGIN
    SELECT event_id FROM event_destroy_confirmation WHERE event_id = idEvent;
  END;
