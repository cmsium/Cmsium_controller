CREATE PROCEDURE checkAddressTablePresence(IN tableName VARCHAR(255))
  BEGIN
    SELECT table_name FROM information_schema.tables WHERE table_name = tableName;
  END;
