CREATE PROCEDURE clearEventExpiredConfirmations()
  BEGIN
    DELETE FROM event_destroy_confirmation WHERE event_destroy_confirmation.expires < NOW();
  END;
