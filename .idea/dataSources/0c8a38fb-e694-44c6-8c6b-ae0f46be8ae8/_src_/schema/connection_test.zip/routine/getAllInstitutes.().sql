CREATE PROCEDURE getAllInstitutes()
  BEGIN
    SELECT * FROM institutes;
  END;
