CREATE PROCEDURE getFileDataFromSandbox(IN idFile VARCHAR(32))
  BEGIN
    SELECT * FROM sandbox_files WHERE file_id = idFile;
  END;
