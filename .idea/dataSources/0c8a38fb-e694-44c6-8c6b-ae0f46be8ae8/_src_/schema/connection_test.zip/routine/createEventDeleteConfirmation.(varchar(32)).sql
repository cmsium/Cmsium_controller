CREATE PROCEDURE createEventDeleteConfirmation(IN idEvent VARCHAR(32))
  BEGIN
    INSERT INTO event_destroy_confirmation(event_id, expires) VALUES (idEvent, DATE_ADD(NOW(), INTERVAL 20 MINUTE));
  END;
