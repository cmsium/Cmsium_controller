CREATE PROCEDURE getCountryByISO(IN countryISO INT)
  BEGIN
    SELECT * FROM address_countries WHERE iso = countryISO;
  END;
