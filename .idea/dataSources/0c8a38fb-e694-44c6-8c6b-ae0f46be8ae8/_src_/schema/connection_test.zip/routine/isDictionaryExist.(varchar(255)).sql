CREATE PROCEDURE isDictionaryExist(IN inDictionarie VARCHAR(255))
  BEGIN
    SELECT * FROM dictionaries WHERE name = inDictionarie;
  END;
