CREATE PROCEDURE getAllCountries()
  BEGIN
    SELECT * FROM address_countries;
  END;
