CREATE PROCEDURE deleteRoleFromActions(IN idRole INT)
  BEGIN
    DELETE FROM roles_in_actions WHERE id_role=idRole;
END;
