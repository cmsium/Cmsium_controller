CREATE PROCEDURE getNameFromKLADRTempByCode(IN codeVal VARCHAR(255), IN idType INT)
  BEGIN
    SELECT name FROM kladr_temp WHERE code = codeVal AND type_id = idType;
  END;
