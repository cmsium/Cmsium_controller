CREATE PROCEDURE createFileFromData(IN idFile  VARCHAR(32), IN createdAt DATETIME, IN fileName VARCHAR(100),
                                    IN idOwner VARCHAR(32))
  BEGIN
    INSERT INTO files (file_id, path, created_at, name, owner_id) VALUES (idFile,'future',createdAt,fileName,idOwner);
  END;
