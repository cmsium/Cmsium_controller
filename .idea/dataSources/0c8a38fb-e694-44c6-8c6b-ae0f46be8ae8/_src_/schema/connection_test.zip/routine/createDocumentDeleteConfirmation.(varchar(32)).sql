CREATE PROCEDURE createDocumentDeleteConfirmation(IN idDocument VARCHAR(32))
  BEGIN
    INSERT INTO document_destroy_confirmation(document_id, expires) VALUES (idDocument, DATE_ADD(NOW(), INTERVAL 20 MINUTE));
  END;
