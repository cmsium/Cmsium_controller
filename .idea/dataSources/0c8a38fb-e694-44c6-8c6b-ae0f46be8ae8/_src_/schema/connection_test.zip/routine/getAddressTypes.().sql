CREATE PROCEDURE getAddressTypes()
  BEGIN
    SELECT * FROM address_types;
  END;
