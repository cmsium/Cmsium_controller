CREATE PROCEDURE getAllBasicActions()
  BEGIN
    SELECT * FROM event_basic_actions;
  END;
