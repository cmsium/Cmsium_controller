CREATE PROCEDURE deleteRoleFromAction(IN idRole INT, IN idAction VARCHAR(32))
  BEGIN
    DELETE FROM roles_in_actions WHERE id_role=idRole AND action_id=idAction;
END;
