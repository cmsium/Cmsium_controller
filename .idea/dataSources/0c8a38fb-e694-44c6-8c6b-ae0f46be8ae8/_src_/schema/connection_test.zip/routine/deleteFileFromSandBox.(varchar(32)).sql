CREATE PROCEDURE deleteFileFromSandBox(IN idFaile VARCHAR(32))
  BEGIN
    DELETE FROM sandbox_files WHERE file_id = idFaile;
  END;
