CREATE PROCEDURE getFilePathById(IN idFile VARCHAR(32))
  BEGIN
    SELECT CONCAT_WS('_', file_id, UNIX_TIMESTAMP(created_at), MD5(name)) as result FROM files WHERE file_id = idFile ;
END;
