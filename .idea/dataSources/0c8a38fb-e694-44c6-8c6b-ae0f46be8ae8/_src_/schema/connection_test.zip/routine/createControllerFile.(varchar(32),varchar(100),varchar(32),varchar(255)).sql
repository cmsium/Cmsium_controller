CREATE PROCEDURE createControllerFile(IN idFile   VARCHAR(32), IN fileName VARCHAR(100), IN idOwner VARCHAR(32),
                                      IN FilePath VARCHAR(255))
  BEGIN
    INSERT INTO controller_files (file_id, path, created_at, file_name, owner_id) VALUES (idFile,FilePath,NOW(),fileName,idOwner);
  END;
