CREATE PROCEDURE checkUserConfirmation(IN idUser VARCHAR(32))
  BEGIN
    SELECT user_id FROM confirmation WHERE user_id = idUser;
  END;
