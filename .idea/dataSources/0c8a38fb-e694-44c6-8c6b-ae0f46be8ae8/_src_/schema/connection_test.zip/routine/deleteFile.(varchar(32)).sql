CREATE PROCEDURE deleteFile(IN idFile VARCHAR(32))
  BEGIN
    DELETE FROM files WHERE file_id=idFile;
  END;
