CREATE PROCEDURE deleteControllerFile(IN idFile VARCHAR(32))
  BEGIN
    DELETE FROM controller_files WHERE file_id=idFile;
  END;
