CREATE PROCEDURE createEventTable(IN typeName VARCHAR(64), IN tableStructure TEXT)
  BEGIN
    START TRANSACTION;
    SET @sql = CONCAT('CREATE TABLE ',
                      CONCAT('event_', typeName),
                      '(event_id varchar(32) NOT NULL, user_id varchar(32) NOT NULL, created_at timestamp NOT NULL, ',
                      tableStructure,
                      'PRIMARY KEY (event_id)) ENGINE=InnoDB'
    );
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    INSERT INTO event_types(name) VALUES (typeName);
    COMMIT;
  END;
