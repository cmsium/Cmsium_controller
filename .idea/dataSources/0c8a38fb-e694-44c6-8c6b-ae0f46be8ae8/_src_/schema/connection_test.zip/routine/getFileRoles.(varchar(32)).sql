CREATE PROCEDURE getFileRoles(IN idFile VARCHAR(32))
  BEGIN
     SELECT role_id,permissions FROM roles_in_files WHERE file_id = idFile;
END;
