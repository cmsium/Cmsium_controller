CREATE PROCEDURE getInstitute(IN instituteId VARCHAR(32))
  BEGIN
    SELECT * FROM institutes WHERE institute_id = instituteId;
  END;
