CREATE PROCEDURE getUser(IN idUser VARCHAR(32))
  BEGIN
    SELECT bus.id_user, e.email, p.phone, props.username, props.firstname, props.middlename, props.lastname,
      props.birthplace, props.birth_date,
      GROUP_CONCAT(DISTINCT r.name ORDER BY r.name ASC SEPARATOR ', ') AS roles
    FROM bus_tickets AS bus
      INNER JOIN user_properties AS props ON bus.id_user = props.user_id
      INNER JOIN emails AS e ON bus.id_user = e.user_id
      INNER JOIN phones AS p ON bus.id_user = p.user_id
      JOIN roles_in_users AS riu ON bus.id_user = riu.user_id
      JOIN roles AS r ON riu.role_id = r.id
    WHERE bus.id_user = idUser;
  END;
