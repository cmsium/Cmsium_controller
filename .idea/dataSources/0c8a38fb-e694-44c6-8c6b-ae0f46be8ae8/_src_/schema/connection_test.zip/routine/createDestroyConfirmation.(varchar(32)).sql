CREATE PROCEDURE createDestroyConfirmation(IN idUser VARCHAR(32))
  BEGIN
    INSERT INTO confirmation(user_id, expires) VALUES (idUser, DATE_ADD(NOW(), INTERVAL 20 MINUTE));
  END;
