CREATE PROCEDURE getFileOwner(IN idFile VARCHAR(32))
  BEGIN
    SELECT owner_id FROM files WHERE file_id = idFile;
  END;
